# Import
from flask import Flask, render_template,request, redirect
from flask_sqlalchemy import SQLAlchemy
import random

app = Flask(__name__)


@app.route("/")
def index():
    return render_template('index.html')

@app.route('/gs')
def gs():
    return render_template('gs.html')

@app.route("/ortam")
def ortam():
    return render_template('ortam.html')


@app.route("/fb")
def fb():
    return render_template('fb.html') 

@app.route("/maryo")
def maryo():
    return render_template('oyunlar.html') 

@app.route("/oyuncular")
def oyuncular():
    return render_template('oyuncular.html') 

@app.route("/messi")
def messi():
    return render_template('messi.html') 

@app.route("/ronaldo")
def ronaldo():
    return render_template('ronaldo.html') 

@app.route("/mbappe")
def mbappe():
    return render_template('mbappe.html') 

@app.route("/lewandoski")
def lewandoski():
    return render_template('lewandoski.html') 

@app.route("/kenan")
def kenan():
    return render_template('kenan.html') 

@app.route("/kaka")
def kaka():
    return render_template('kaka.html') 

@app.route("/halland")
def halland():
    return render_template('haland.html') 

@app.route("/hakan")
def hakan():
    return render_template('hakan.html') 

@app.route("/arda_güler")
def arda ():
    return render_template('arda_guler.html') 

@app.route("/556")
def sinipers ():
    return render_template('jungles_sinipers.html') 


@app.route("/123098")
def dino ():
    return render_template('dino.html') 

@app.route("/123")
def arena ():
    return render_template('piramids.html') 


@app.route("/1234")
def space ():
    return render_template('space.html') 


@app.route("/12345")
def puzulle ():
    return render_template('puzulle.html') 


@app.route("/123456")
def trafic ():
    return render_template('trafic.html') 


@app.route("/12345678")
def journer ():
    return render_template('journer.html') 


@app.route("/123456789")
def neon ():
    return render_template('neon.html') 

@app.route("/1234567890")
def killer ():
    return render_template('killer.html') 







if __name__ == "__main__":
    app.run(debug=True)
